
# Changelog

## [1.0.0](https://github.com/keerthana-bot/Base/tree/1.0.0) (2023-09-10)

[Full Changelog](https://github.com/keerthana-bot/Base/compare/v1.0.0...1.0.0)

- Create the Base